-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 19, 2010 at 11:12 AM
-- Server version: 5.0.85
-- PHP Version: 5.2.11

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `a6360719_32919`
--

-- --------------------------------------------------------

--
-- Table structure for table `product_db`
--

CREATE TABLE `product_db` (
  `product_id` int(11) NOT NULL auto_increment,
  `product_name` varchar(80) NOT NULL,
  `author` varchar(60) NOT NULL,
  `product_desc` text,
  `product_serial` varchar(20) NOT NULL,
  `product_category` varchar(40) NOT NULL,
  `product_price` decimal(7,2) NOT NULL,
  `onSales` enum('false','true') NOT NULL default 'false',
  `bestSeller` enum('false','true') NOT NULL default 'false',
  `product_type` enum('cd','book') NOT NULL default 'book',
  `sold` int(10) NOT NULL default '0',
  `availability` enum('false','true') NOT NULL default 'true',
  `createdate` datetime NOT NULL,
  PRIMARY KEY  (`product_id`,`product_serial`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `product_db`
--

INSERT INTO `product_db` VALUES(1, 'CODEX', 'ΛΥΓΕΡΟΣ ΝΙΚΟΣ', 'Πόση από τη Γενική Σχετικότητα οφείλεται στον Καραθεοδωρή; Πώς σχετίζονται τα μαθηματικά με τη νοημοσύνη; Με τη δημιουργικότητα; Ο κόσμος μας είναι απλός ή πολύπλοκος; Η επιστήμη είναι αισιόδοξη ή απαισιόδοξη; Πόσο ανθρώπινη είναι η τεχνολογία; Ποια η σχέση της επιστήμης με την τέχνη; Τι έχει να μας πει επ\\'' αυτού ο Leonardo da Vinci; Μια γοητευτική περιπλάνηση του ευφυέστερου Έλληνα στον κόσμο των μαθηματικών, και όχι μόνο. Το διεισδυτικό βλέμμα του Νίκου Λυγερού ατενίζει τη σύγχρονη επιστήμη υπό το πρίσμα της ανθρωπιάς, προχωρώντας ενίοτε στις φιλοσοφικές προεκτάσεις της. Με ζήλο κι επιστημοσύνη, ο συγγραφέας σκιαγραφεί την προσωπικότητα του επιφανούς μαθηματικού Κωνσταντίνου Καραθεοδωρή, ιχνηλατώντας παράλληλα την πορεία του Einstein έως τη Γενική Θεωρία της Σχετικότητας. Μαθηματικά, κβαντομηχανική, θερμοδυναμική, κρυπτογραφία, κυβερνητική, κοινωνιολογία, εκπαίδευση και τέχνη συγκροτούν ένα καλειδοσκόπιο –ενίοτε ρηξικέλευθων, πάντα όμως βαθιά ανθρώπινων– στοχασμών που σαγηνεύει, ερεθίζει, προκαλεί. ', '9789607182517', 'Eπιστήμη και τεχνολογία (Eκλαικευμένη - ', 36.00, 'true', 'false', 'book', 8, 'true', '2010-01-05 01:00:00');
INSERT INTO `product_db` VALUES(2, 'ΜΕΤΑΞΥ ΣΦΥΡΑΣ ΚΑΙ ΑΛΙΑΚΜΟΝΟΣ', 'ΣΚΑΜΠΑΡΔΩΝΗΣ ΓΙΩΡΓΟΣ', 'Στα διηγήματα αυτά κυριαρχούν κι επανέρχονται θέματα από το οικείο σύμπαν του συγγραφέα: τα άφεγγα μέρη, οι αναδιπλώσεις της μνήμης, οι υπόγειες κρύπτες. Το ανεπαλήθευτο, το παίγνιο, οι εμμονές: το νερό, η θάλασσα, η υπέρβαση της αντοχής, η απώλεια. Οι δύσκολες σχέσεις, η φθορά, η κρίσιμη στιγμή που φέρνει την αλλοίωση και σε ορίζει. Η μοναχικότητα, τα ζώα, ο φόβος, η πνιγμονή, ο ακρωτηριασμός, η πτήση, το αναπάντεχο. Η μεγάλη αναμονή, η ματαιότητα, η Ιστορία που διαβρώνει το τώρα. Η ειρωνεία του τυχαίου που μεταβάλλει τα πάντα. Τα μεγάλα κατορθώματα που γλυκαίνουν παλιές μαχαιριές. Το κενό, ως μουσική που πυκνώνει και παρηγορεί.\r\n\r\nΣταθερά θέματα που φεύγουν, επανέρχονται μεταμφιεσμένα κι αντανακλούν σε 27 διηγήματα υφασμένα πάνω σε σταθερές, αόρατες γραμμές και σε ρευστά σχέδια, μεταξύ μιας ύπερθεν μοίρας και του σουρεαλισμού της πραγματικότητας, μεταξύ σφύρας και Αλιάκμονος.', '9789601905013', 'Eλληνική λογοτεχνία', 14.40, 'true', 'false', 'book', 6, 'true', '2010-01-05 03:00:00');
INSERT INTO `product_db` VALUES(3, 'Σ'' ΕΝΑ ΣΤΡΑΤΟΠΕΔΟ ΑΚΡΗ ΣΤΗΝ ΕΡΗΜΙΑ', 'ΚΟΥΜΑΝΤΑΡΕΑΣ ΜΕΝΗΣ', 'Σ'' ένα απομονωμένο στρατόπεδο, ένας αγγελόμορφος στρατιώτης ζωγραφίζει με την προτροπή της γυναίκας του Στρατηγού τον σύζυγό της και διοικητή του. Ο πίνακας θ'' αποκαλύψει κρυφές πτυχές των ηρώων αλλά και της ίδιας της τέχνης της ζωγραφικής. Μια ιστορία στην οποία αποσιωπούνται τα ονόματα των πρωταγωνιστών αλλά πολλές φορές και οι επιθυμίες τους, και όπου μια υπόγεια αίσθηση απειλής παραμονεύει ήρωες και αναγνώστες. Χρόνια αργότερα, όταν ο πίνακας γίνεται λαϊκό προσκύνημα σε μια πινακοθήκη, όλα πια θα έχουν πάρει τις διαστάσεις θρύλου.\r\n\r\nΑπό τις λιγοστές φορές που ο Μένης Κουμανταρέας δε γράφει για την Αθήνα του χθες ή του σήμερα, αλλά για ένα φανταστικό στρατόπεδο χαμένο κάπου μέσα στο χρόνο. Μια νουβέλα που ισορροπεί ανάμεσα στην παραβολή και στο παραμύθι.', '9789600439298', 'Eλληνική λογοτεχνία', 10.00, 'true', 'false', 'book', 3, 'true', '2010-01-05 04:00:00');
INSERT INTO `product_db` VALUES(4, 'INTRODUCTION TO ALGORITHMS', 'CORMEN, LEISERSON, RIVEST', 'Some books on algorithms are rigorous but incomplete; others cover masses of material but lack rigor. Introduction to Algorithms uniquely combines rigor and comprehensiveness. The book covers a broad range of algorithms in depth, yet makes their design and analysis accessible to all levels of readers. Each chapter is relatively self-contained and can be used as a unit of study. The algorithms are described in English and in a pseudocode designed to be readable by anyone who has done a little programming. The explanations have been kept elementary without sacrificing depth of coverage or mathematical rigor. The first edition became a widely used text in universities worldwide as well as the standard reference for professionals. The second edition featured new chapters on the role of algorithms, probabilistic analysis and randomized algorithms, and linear programming. The third edition has been revised and updated throughout. It includes two completely new chapters, on van Emde Boas trees and multithreaded algorithms, and substantial additions to the chapter on recurrences (now called "Divide-and-Conquer"). It features improved treatment of dynamic programming and greedy algorithms and a new notion of edge-based flow in the material on flow networks. Many new exercises and problems have been added for this edition. As of the third edition, this textbook is published exclusively by the MIT Press.', '9780262533058', 'Computer programming', 56.00, 'false', 'false', 'book', 3, 'true', '2010-01-05 05:00:00');
INSERT INTO `product_db` VALUES(5, 'Team Foundation Server', 'Jamil,Azher', 'Server programming', '9781933988597', 'Computer programming', 40.00, 'false', 'false', 'book', 3, 'true', '2010-01-05 06:00:00');
INSERT INTO `product_db` VALUES(6, 'The PHP Anthology', 'Ben,Balbo, Harry,Fuecks, Matthew Weler,O''Phinney, Davey,Shaf', 'The PHP Anthology: 101 Essential Tips, Tricks & Hacks, 2ndEdition is a collection of powerful PHP 5 solutions to themost common programming problems. Featuring best-practice code and a commonsense approach todevelopment, this book includes coverage of: Manage errors gracefully.Build functional forms, tables, and SEO-friendly URLs.Reduce load time with client- and server-side caching.Produce and utilize web services with XML.Secure your site using access control systems.Easily work with files, emails, and images.And much more The question and answer format will allow you to to quicklyfind and reference any of the 101 solutions, saving youhours of Internet research or painful trial & error. Allsolutions are fully explained and the ready-to-use code isavailable for download. From the Publisher "A comprehensive collection of ready-to-use PHP solutions!" Over 100 easy-to understand PHP tips, tricks and hacks. Save hours of time with "copy and paste" ready code. All solutions are fully explained by five PHP gurus. Learn the very latest object oriented PHP techniques. And so much more...Each chapter of this book is laid out in a problem-solutionformat. We''ll start with a common PHP problem that you mayface, and then provide a concise solution to that problem.In some cases, when the topic warrants it, we''ll give you abrief discussion of the solution to provide context. The chapters are grouped to cover the major areas of PHP.Inside, you''ll find solutions to the most common challenges that PHP developers face. What Slashdot.org Says "The chapters on error handling and access control are aloneworth the price of the book".', '9780975841990', 'Computer programming', 35.30, 'true', 'true', 'book', 4, 'true', '2010-01-05 07:00:00');
INSERT INTO `product_db` VALUES(7, 'Microsoft VBScript Step by Step', 'E.,Wilson', 'Get guidance from a well-known scripting expert and teach yourself the fundamentals of Microsoft Visual Basic Scripting Edition (VBScript). This tutorial delivers hands-on, self-paced learning labs to help you get started automating Microsoft Windows administration one step at a time. Discover how to: Manage folders and files with a single script Configure network components with Windows Management Instrumentation Administer users and groups using subroutines and Active Directory Service Interfaces (ADSI) Design logon scripts to configure and maintain user environments Monitor and manage network printers Back up and edit the registry avoiding common pitfalls Handle errors and troubleshoot scripts Simplify administration for Microsoft Exchange Server 2003 and Internet Information Services 6.0 Includes a CD featuring: All practice exercises 100+ sample scripts to adapt for your own work.', '0735622973', 'Computer programming', 37.70, 'false', 'false', 'book', 3, 'true', '2010-01-05 08:00:00');
INSERT INTO `product_db` VALUES(8, 'The Source', 'FREEMAN, MICHAEL', 'Interior design has undergone a quiet but profound revolution in the last decade, as home-owners have become more aware of international influences and more prepared to experiment, to break out of the prescribed moulds of style. Many different parts of the world in particular India, China, and Japan have evolved their own unique styles of modernism, much of it rooted in the traditional principles of their particular regions, and this has helped to liberate the way we now think about dwelling space, its organisation and furnishing. Drawing on a wide range of modern design from many countries, this unique, rich sourcebook takes an elemental approach to the design of a home. In an age when no interior design principle goes unchallenged and all ideas are possible, the only sensible approach is to start from the basic elements how a home works and what we expect from it. The Source, illustrated with hundreds of colour photographs by Michael Freeman, one of the most widely travelled authors and photographers working in this area, is divided into four sections which each cover a basic function. The first, Connect, deals with the connectivity of a home, from entrances and corridors to staircases. The second, Divide, shows the many ways in which individual areas can be divided and linked, from walls to screens and unconventional dividers, as well as flexible partitions that draw on Japanese and Chinese principles. The third section, Space, is concerned with living spaces in all their variety, balancing the twin needs of comfort and inspiration. The last section, Utility, covers the basic functions of any dwelling, from cooking and bathing to working at home and storage. All of this is illustrated by a vast array of ideas and solutions from many of the worlds best interior designers and architects. This new book offers a different and refreshing way of looking at the house and the elemental way of how we live today.', '9780955432248', 'Architecture', 29.90, 'false', 'false', 'book', 3, 'true', '2010-01-05 09:00:00');
INSERT INTO `product_db` VALUES(9, 'Simply The Best', 'Julie Massino', 'Ερμηνίες απο την Julie Massino', '010101010101', 'Dance', 12.00, 'false', 'false', 'cd', 3, 'true', '2010-01-08 08:17:31');
INSERT INTO `product_db` VALUES(10, 'Fear Of The Dark', 'Iron Maiden ', 'Fear of the Dark is the ninth studio album released by British heavy metal band Iron Maiden. It topped the UK albums chart. Released on 11 May 1992, it was the final studio album to feature Bruce Dickinson as lead vocalist who left the band following the album''s support tour to pursue a solo career. He was succeeded by Blaze Bayley, formerly of Wolfsbane, for two studio albums until Dickinson returned to Iron Maiden for the 2000 release of Brave New World.', '123456789', 'Metal', 25.00, 'false', 'true', 'cd', 13, 'true', '2010-01-08 08:21:43');
INSERT INTO `product_db` VALUES(11, 'Systematic Chaos', 'Dream Theater', 'Systematic Chaos is the ninth studio album by American progressive metal band Dream Theater. Released on June 4, 2007 in the United Kingdom and June 5, 2007 in the United States, Systematic Chaos was the band''s first release through Roadrunner Records. The album was recorded from September 2006 to February 2007 at Avatar Studios in New York City, after the band''s first break from summer touring in ten years. The lyrics of the album were written by John Petrucci, James LaBrie, and Mike Portnoy about fictional, political, and personal topics, respectively.', '1111111', 'Metal', 35.00, 'true', 'true', 'cd', 11, 'true', '2010-01-08 08:29:51');
INSERT INTO `product_db` VALUES(15, 'C Θεωρία και Πράξη', 'Αλεξανδρος Τομαράς', 'Βασικές γνώσεις και πολλα παραδείγματα τις γλώσσας προγραματισμού C.', '123465789', 'Εκπαιδευτικό', 10.00, 'true', 'false', 'book', 3, 'true', '2010-01-10 20:03:17');
INSERT INTO `product_db` VALUES(12, 'Balls To Picasso', 'Bruce Dickinson', '   1. "Cyclops" - 7:58\r\n   2. "Hell No" - 5:11\r\n   3. "Gods of War" - 5:02\r\n   4. "1000 Points of Light" - 4:25\r\n   5. "Laughing in the Hiding Bush" - 4:20\r\n   6. "Change of Heart" - 4:58\r\n   7. "Shoot All the Clowns" - 4:24 - #37 UK\r\n   8. "Fire" - 4:30\r\n   9. "Sacred Cowboys" - 3:53\r\n  10. "Tears of the Dragon" - 6:24 - #28 UK, #36 US\r\n', '123456789', 'Hard rock', 25.00, 'false', 'true', 'cd', 3, 'true', '2010-01-08 11:07:13');
INSERT INTO `product_db` VALUES(13, 'Black Rain', 'Ozzy Osbourne', 'Osbourne has stated that this is the first album he has recorded sober.[2] It featured a new musical style for him and was his first album to feature elements of industrial metal and thrash metal.[citation needed] Though his lyrical style remained similar to before, the album featured many elements not seen in previous albums, such as distorted vocals, heavier guitars, and the higher usage of synthesizers. The latter may be because of the fact that this is the first album to not feature a keyboardist in Osbourne''s backup band, and guitarist Zakk Wylde filled the spot for the album, and sometimes chose to add a keyboard solo to a song rather than a guitar solo.', '123456789', 'Industrial Metal', 25.00, 'true', 'false', 'cd', 3, 'true', '2010-01-08 11:08:42');
INSERT INTO `product_db` VALUES(14, 'Hotel', 'Moby', 'The album name Hotel was explained in one of Moby''s journal entries. The artist was fascinated by the nature of hotels, where humans spend often significant portions of their lives, but have all traces of their tenancy removed for the next guests.[1]\r\n\r\nHotel is the first Moby album in several years that does not contain any vocal samples. The album showcases a wide range of genres, from electronic to disco. Moby is responsible for playing the instruments on all the tracks, except for drumming. Laura Dawn provides additional vocals. The first UK single was "Lift Me Up", released February 28, 2005. The second UK single, "Spiders," was released on May 23, 2005 to coincide with Moby''s UK tour. The album includes a ballad cover of New Order''s "Temptation".', '123456789', '	Electro rock, Dance, Electronica, Ambie', 25.00, 'false', 'false', 'cd', 3, 'true', '2010-01-08 11:11:03');
INSERT INTO `product_db` VALUES(16, 'ADE', 'ADE', 'asdasdasd', '00000000', 'Ergasitrio', 10.00, 'true', 'true', 'cd', 0, 'true', '2010-01-11 15:07:01');

-- --------------------------------------------------------

--
-- Table structure for table `sales_db`
--

CREATE TABLE `sales_db` (
  `sales_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `address` varchar(80) default NULL,
  `tel_num` varchar(15) default NULL,
  `delivery_date` datetime NOT NULL,
  `finall_price` double(10,3) NOT NULL,
  `package` enum('doro','aplo') NOT NULL,
  `delivery_orders` enum('express','person_public_mail','public_mail') default NULL,
  `quantity` smallint(4) NOT NULL default '1',
  PRIMARY KEY  (`sales_id`),
  KEY `user` (`user_id`),
  KEY `product` (`product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `sales_db`
--

INSERT INTO `sales_db` VALUES(27, 1, 3, 'Spiti', '6940000000', '2010-01-08 12:28:58', 10.000, 'aplo', '', 1);
INSERT INTO `sales_db` VALUES(28, 1, 10, 'Spiti', '6940000000', '2010-01-08 12:28:58', 50.000, 'aplo', '', 2);
INSERT INTO `sales_db` VALUES(29, 1, 14, 'Spiti', '6940000000', '0000-00-00 00:00:00', 25.000, 'doro', 'express', 1);
INSERT INTO `sales_db` VALUES(30, 1, 4, 'Spiti', '6940000000', '0000-00-00 00:00:00', 56.000, 'doro', 'express', 1);
INSERT INTO `sales_db` VALUES(31, 16, 10, 'Κερκυρα', '6940000000', '2010-01-10 20:08:13', 50.000, 'aplo', '', 2);
INSERT INTO `sales_db` VALUES(32, 16, 3, 'Κερκυρα', '6940000000', '2010-01-10 20:09:37', 100.000, 'doro', '', 10);
INSERT INTO `sales_db` VALUES(33, 1, 4, 'Spiti', '6940000000', '2010-01-10 20:24:37', 112.000, 'doro', '', 2);
INSERT INTO `sales_db` VALUES(34, 16, 14, 'Κερκυρα', '6940000000', '2010-01-10 20:39:50', 25.000, 'aplo', '', 1);
INSERT INTO `sales_db` VALUES(35, 16, 14, 'Κερκυρα', '6940000000', '2010-01-10 20:40:11', 25.000, 'aplo', '', 1);
INSERT INTO `sales_db` VALUES(36, 16, 14, 'Κερκυρα', '6940000000', '2010-01-10 21:20:37', 25.000, 'aplo', '', 1);
INSERT INTO `sales_db` VALUES(37, 1, 15, 'Spiti', '6940000000', '2010-01-10 22:08:34', 10.000, 'aplo', '', 1);
INSERT INTO `sales_db` VALUES(38, 1, 13, 'Spiti', '6940000000', '2010-01-10 22:09:16', 25.000, 'aplo', '', 1);
INSERT INTO `sales_db` VALUES(39, 1, 11, 'Spiti', '6940000000', '2010-01-10 22:09:45', 35.000, 'aplo', '', 1);
INSERT INTO `sales_db` VALUES(40, 1, 3, 'Spiti', '6940000000', '2010-01-10 22:10:35', 10.000, 'aplo', '', 1);
INSERT INTO `sales_db` VALUES(41, 21, 3, 'asd', '', '2010-01-11 15:02:27', 10.000, 'aplo', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tempcart_db`
--

CREATE TABLE `tempcart_db` (
  `sales_id` int(10) NOT NULL auto_increment,
  `user_id` int(10) NOT NULL,
  `product_id` int(10) NOT NULL,
  `quantity` smallint(4) NOT NULL default '1',
  PRIMARY KEY  (`sales_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=97 ;

--
-- Dumping data for table `tempcart_db`
--

INSERT INTO `tempcart_db` VALUES(95, 21, 13, 1);
INSERT INTO `tempcart_db` VALUES(96, 21, 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Users_db`
--

CREATE TABLE `Users_db` (
  `user_id` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(20) NOT NULL,
  `password` char(40) NOT NULL,
  `firstname` varchar(40) NOT NULL,
  `lastname` varchar(40) NOT NULL,
  `createdate` timestamp NULL default '0000-00-00 00:00:00',
  `lastlogin` timestamp NULL default NULL,
  `mail` varchar(50) default NULL,
  `address` varchar(40) default NULL,
  `contact_phone` varchar(15) default NULL,
  `accesslvl` enum('Administrator','Author','User') NOT NULL default 'User',
  `registered` enum('false','true') NOT NULL default 'true',
  `age` varchar(3) default NULL,
  `sex` enum('female','male') NOT NULL default 'male',
  `edu` enum('Master','university','2o level','1o level') NOT NULL default '1o level',
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `Users_db`
--

INSERT INTO `Users_db` VALUES(1, 'Nickmix', '49fb059970a165ddded072b8a3cdf06d', 'Nikos', 'Armenis', '2009-11-24 02:24:13', '2010-01-10 22:08:29', 'armenis@hotmail.com', 'Spiti', '6940000000', 'Administrator', 'true', '23', 'male', 'Master');
INSERT INTO `Users_db` VALUES(16, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin', 'admin', '2010-01-07 11:21:20', '2010-01-11 15:05:53', 'admin@armenis.com', 'Κερκυρα', '6940000000', 'Administrator', 'true', '23', 'male', 'university');
INSERT INTO `Users_db` VALUES(17, 'kostas', 'e10adc3949ba59abbe56e057f20f883e', 'Konstantinos', 'Tsimaris', '2010-01-07 11:21:53', '2010-01-07 11:22:04', 'ktsimaris@mycosmos.gr', '123 deksia fanaria  , apenanti', 'to exeis', 'Administrator', 'true', 'oxi', 'male', '1o level');
INSERT INTO `Users_db` VALUES(18, 'manager', '1d0258c2440a8d19e716292b231e3190', 'manager', 'manager', '2010-01-08 06:32:51', '2010-01-11 15:08:06', 'manager@armenis.com', '', '6943333333', 'Author', 'true', '23', 'male', 'university');
INSERT INTO `Users_db` VALUES(21, 'user1', '24c9e15e52afc47c225b757e7bee1f9d', 'user1', 'user1', '2010-01-11 15:01:03', '2010-01-11 15:01:23', 'asd', 'asd', '', 'User', 'true', '21', 'male', '1o level');
